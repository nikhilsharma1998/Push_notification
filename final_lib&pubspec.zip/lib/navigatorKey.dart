import 'package:flutter/cupertino.dart';

GlobalKey<NavigatorState>? navigatorKey = GlobalKey<NavigatorState>();
